import React from 'react'
import styled from 'styled-components'
import all from "../Assets/all.png"
import craft from "../Assets/crafts.png"
import fbn from "../Assets/fbn.png"
import vu from "../Assets/vu.jpg"
import tiz from "../Assets/tiz.jpg"
import one from "../Assets/partners1.jpg"
import two from "../Assets/partners2.jpg"
import three from "../Assets/partners3.jpg"
import four from "../Assets/partners4.jpg"
import five from "../Assets/partners5.jpg"
import six from "../Assets/partners6.jpg"

const Vid = () => {
  return (
    <Container>
        <Wrapper>
            <Card>
                <iframe 
                width="1600" 
                frameBorder="none"
                height="480" 
                src="https://www.youtube.com/embed/eNrF5YQvaeg" 
                title="YouTube video player" 
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture">
            </iframe>
            </Card>
                
        </Wrapper>
    </Container>
  )
}

export default Vid
const VidHold = styled.div`
    width: 100%;
    height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
    background: rgba(0, 0, 0, 0.7);
    position: absolute;
    top: 0;
    position: fixed;
`
const Card = styled.div`
     width: 100%;
    height: 100%;
    display: flex;
    justify-content: center;
    align-items: center;
`
const Down = styled.div`
    width: 100%;
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-top: 20px;
`
const Tiz = styled.img`
    height: 85px;
`
const Vu = styled.img`
    height: 85px;
`
const Fbn = styled.img`
    height: 85px;
`
const Craft = styled.img`
    height: 75px;
`
const All = styled.img`
    width: 100%;
    height: 100%;
    object-fit: cover;
`
const Up = styled.div`
    width: 100%;
    display: flex;
    align-items: center;
    justify-content: space-between;
`
const Imagehold = styled.div`
    width: 80%;
    display: flex;
    align-items: center;
    flex-direction: column;
    margin-left: 80px;
    /* background-color: red; */
    margin-top: 50px;
`
const P = styled.div`
    font-weight: 500;
    font-size: 19px;
    line-height: 1.25rem;
    margin-left: 80px;
    /* background-color: red; */
    width: 85%;
`

const Top = styled.div`
    h2{
        font-weight: 700;
        font-size: 43px;
        line-height: 2rem;
    }
    margin-left: 80px;
`

const Wrapper = styled.div`
    width: 75%;
    display: flex;
    border-radius: 20px;
    justify-content: center;
    /* background-color: red; */
    overflow: hidden;
`

const Container = styled.div`
    width: 100%;
    display: flex;
    justify-content: center;
    padding-top: 25px;
    padding-bottom: 25px;
`