import React from "react";
import styled from "styled-components";
// import hero from "../About/Assets/Insurance.png";

const StandFor = () => {
  return (
    <div>
      <Container>
        <Left>
          <First>
            <p>WHAT WE STAND FOR</p>
          </First>
          <Second>
            <h2>Insurance should be easily accessible to anyone</h2>
          </Second>
          <Third>
            <p>
              PaddyCover works with established insurers and customer
              aggregators to design and offer bespoke products via a
              multi-channel platform that facilitates flexible and convenient
              payment for insurance packages.{" "}
            </p>

            <p>
              Our focus is to adopt and distribute key Insurance products e.g.
              Life and Health & Wellbeing Insurance - amongst others - as a
              means of building a model of prevention towards risk &
              strengthening resilience in our addressable market.
            </p>

            <p>
              Paddycover innovatively takes the off-the-shelve products of
              underwriters and then work with them to create bespoke products (
              to fit price and need) for its customers (who are aggregators).
            </p>
          </Third>
        </Left>
        <Right>
          {/* <img src={hero} alt="" /> */}
        </Right>
      </Container>
    </div>
  );
};

export default StandFor;

const Third = styled.div`
  p {
    margin: 8px 0px;
    font-size: 15.2px;
    font-family: "Trebuchet MS", "Lucida Sans Unicode", "Lucida Grande",
      "Lucida Sans", Arial, sans-serif;
    line-height: 1.2rem;
    letter-spacing: 0.3px;
    color: #000000dd;
  }
`;

const Second = styled.div`
  h2 {
    margin: 0;
    font-size: 2rem;
    font-weight: 500;
    color: #000000db;
    margin-bottom: 20px;

    @media screen and (max-width: 500px) {
      font-size: 1.8rem;
      line-height: 1.7rem;
    }
  }
`;

const First = styled.div`
  p {
    color: #3e4095;
    font-weight: 400;
    text-transform: capitalize;

    @media screen and (max-width: 500px) {
      font-size: 15px;
    }
  }
`;

const Right = styled.div`
  width: 670px;
  display: flex;
  justify-content: flex-end;
  align-items: flex-end;
  /* background-color: red; */

  img {
    margin-top: 40px;
  }

  @media screen and (max-width: 500px) {
    justify-content: flex-start;
  }
`;

const Left = styled.div`
  width: 670px;
  /* background-color: brown; */
`;

const Container = styled.div`
  width: 85%;
  margin: auto;
  display: flex;
  flex-wrap: wrap;

  @media screen and (max-width: 500px) {
    width: 90%;
  }
`;
