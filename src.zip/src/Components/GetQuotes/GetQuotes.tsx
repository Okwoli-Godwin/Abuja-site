import React from "react";
import styled from "styled-components";


const GetQuote = () => {
  return (
    <div>
      <Container>
        <Wrapper>
          <h3>Multiple option insurance premium</h3>
          <h1>Get a quote in a blink of an eye</h1>
          <p>
            To give you the best quality of insurance. Our partners are renowned
            insurance providers in the country with optimal services to their
            credits
          </p>
          <button>{`Get Cover >`}</button>
        </Wrapper>
      </Container>
    </div>
  );
};

export default GetQuote;

const Wrapper = styled.div`
  width: 50%;
  margin-left: 130px;
  height: 100%;
  display: flex;
  justify-content: center;
  flex-direction: column;
  flex-wrap: wrap;

  h1 {
    font-size: 40px;
    line-height: 39px;
    width: 500px;
    font-weight: 500;
    margin: 0;
  }

  h3 {
    font-size: 16px;
    line-height: 1.25rem;
    font-weight: 400;
  }
  p {
    font-size: 1.125rem;
    line-height: 1.75rem;
    width: 250px;
    margin-bottom: 50px;
  }
  button {
    padding: 12px 23px;
    background-color: #3e4095;
    color: #fff;
    width: 140px;

    font-size: 16px;
    font-weight: 500;
    border: 0;
    border-radius: 5px;

    :hover {
      cursor: pointer;
    }
  }
`;

const Container = styled.div`
  width: 100%;
  height: 80vh;
  background-color: #e4f0e9;

  background-position: right bottom;
  background-size: 60%;
  background-repeat: no-repeat;

  @media screen and (max-width: 768px) {
    display: none;
  }
`;
