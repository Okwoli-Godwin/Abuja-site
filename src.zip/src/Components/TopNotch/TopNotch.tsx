import React from "react";
import styled from "styled-components";


const TopNotch = () => {
  return (
    <div>
      <Container>
        <Wrapper>
          <h2>Top Notch Insurance Services</h2>
          {/* <img src={wave} alt="" /> */}
        </Wrapper>
      </Container>
    </div>
  );
};

export default TopNotch;

const Wrapper = styled.div`
  width: 85%;
  margin: auto;

  h2 {
    width: 150px;
    font-weight: 600;
    color: white;

    @media screen and (max-width: 500px) {
      width: 100%;
    }
  }

  img {
    height: 22vh;
    position: absolute;
    top: 0;
    right: 300px;

    @media screen and (max-width: 500px) {
      display: none;
    }
  }
`;

const Container = styled.div`
  width: 100%;
  height: 22vh;
  background-color: #345844;
  display: flex;
  justify-content: center;
  align-items: center;
  position: relative;
`;
