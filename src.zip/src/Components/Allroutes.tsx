import React from 'react'
import {useRoutes} from "react-router-dom"
import About from './About/About'
import Homescreen from './Homescreen/Homescreen'
import Gallery from "./Gallery/Gallery"
import Contact from './Contact/Contact'
import Journal from './Journal/Journal'
import Admin from './Admin/Admin'
import Signin from './SignIn/SignIn'
import Signup from "./Signup/Signup"
import Adminhead from './Adminhead/Adminhead'

const Allroutes = () => {

    const element = useRoutes([
        {
            path: "/",
            children: [
                {
                    index: true,
                    element: <Homescreen />
                },
                {
                    path: "/about",
                    element: <About />
                },
                {
                    path: "/gallery",
                    element: <Gallery />
                },
                {
                    path: "/contact us",
                    element: <Contact />
                },
                {
                    path: "/journal",
                    element: <Journal />
                },
                {
                    path: "Admin",
                    children: [
                        {
                            index: true,
                            element: <Signin />
                        },
                    ]
                },
            ]
        },
        {
            path: "/signin",
             element: <Signin />
        },
        {
            path: "/signup",
            element: <Signup />
        },
        {
            path: "/Adminhome",
            element: <Admin />
        }
    ])
  return element
}

export default Allroutes