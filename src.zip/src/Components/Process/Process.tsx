import React from 'react'
import styled from 'styled-components'
import img from "../Assets/pitch.jpeg"

const Process = () => {
  return (
    <Container>
        <Wrapper>
            <Left>
                <Img src={img} />
            </Left>
            <Right>
                <Top><h3>Grant process</h3></Top>
                <Top><h3>Semester/Course System</h3></Top>
                <ul>
                    <li>
                        Center for Undergraduate Research (CUR) is a center which seeks to develop young researchers through grants from within and outside the University
                    </li>
                    <li>
                        It is a Catch Them Young approach to help promote research culture among undergraduate students in University of Abuja
                    </li>
                    <li>
                        These young researchers are mentored and guided by lecturers on how best to tap into their talents and potentials
                    </li>
                    <li>
                        These young researchers are mentored and guided by lecturers on how best to tap into their talents and potentials
                    </li>
                    <li>
                        These young researchers are mentored and guided by lecturers on how best to tap into their talents and potentials
                    </li>
                    <li>
                        These young researchers are mentored and guided by lecturers on how best to tap into their talents and potentials
                    </li>
                    <li>
                        These young researchers are mentored and guided by lecturers on how best to tap into their talents and potentials
                    </li>
                    <li>
                        These young researchers are mentored and guided by lecturers on how best to tap into their talents and potentials
                    </li>
                    <li>
                        These young researchers are mentored and guided by lecturers on how best to tap into their talents and potentials
                    </li>
                </ul>
            </Right>
        </Wrapper>
    </Container>
  )
}

export default Process
const Nature = styled.div`
    display: flex;
    flex-direction: column;
    p{
        margin: 0;
    }
`
const Top = styled.div`
    h3{

    }
    li{
        margin-bottom: 15px;
    }
`
const Right = styled.div`
    width: 63%;
    display: flex;
    background-color: pink;
    flex-direction: column;
    padding-left: 15px;
    margin-top: -60px;
`
const Img = styled.img`
    width: 100%;
    height: 100%;
    object-fit: cover;
`
const Left = styled.div`
    width: 35%;
    display: flex;
    height: 400px;
    background-color: red;
    margin-top: -100px;
`
const Wrapper = styled.div`
    width: 90%;
    display: flex;
    align-items: center;
    /* padding-top: 10px; */
    justify-content: space-between;
    background-color: yellow;
`
const Container = styled.div`
    width: 100%;
    height: 100vh;
    background-color: green;
    /* margin-top: 425px; */
    display: flex;
    justify-content: center;
    /* z-index: 123456789; */
    /* display: none; */
`