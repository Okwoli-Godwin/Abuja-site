import React from 'react'
import {useRoutes} from "react-router-dom"
import About from './About/About'
import Homescreen from './Homescreen/Homescreen'
import Gallery from "./Gallery/Gallery"
import Contact from './Contact/Contact'
import Journal from './Journal/Journal'
import Admin from './Admin/Admin'

const Allroutes = () => {

    const element = useRoutes([
        {
                    path: "/Admin/about",
                    element: <About />
                },
                {
                    path: "/gallery",
                    element: <Gallery />
                },
                {
                    path: "/contact us",
                    element: <Contact />
                },
                {
                    path: "/journal",
                    element: <Journal />
                },
                {
                    path: "/Admin",
                    element: <Admin />
                },
    ])
  return element
}

export default Allroutes