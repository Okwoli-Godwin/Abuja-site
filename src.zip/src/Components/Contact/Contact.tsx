import React from 'react'
import Header from '../Header/Header'

const Contact = () => {
  return (
    <div>

    </div>
  )
}

export default Contact