import React from "react";
import styled from "styled-components";

const Pay = () => {
  return (
    <div>
      <Container>
        <Top>
          <h2>Pay as you go insurance you control</h2>
          <p>
            We embed our insurance product into your lifestyle and enable you
            have the flexibility of payment
          </p>
        </Top>
        <Bottom>
          <button type="submit">{`Get cover >`}</button>
        </Bottom>{" "}
        {/* <img src={hand} alt="" /> */}
      </Container>
    </div>
  );
};

export default Pay;

const Top = styled.div`
  z-index: 5;
  h2 {
    width: 500px;
    font-size: 40px;
    line-height: 39px;
    margin: 0;
    font-weight: 500;
  }

  p {
    width: 500px;
    font-size: 1.125rem;
    line-height: 1.75rem;
  }
`;
const Bottom = styled.div`
  button {
    padding: 13px 22px;
    background-color: #339f61;
    color: #fff;
    font-size: 16px;
    font-weight: 600;
    border: 0;
    border-radius: 5px;

    :hover {
      cursor: pointer;
    }
  }
`;

const Container = styled.div`
  width: 75%;
  padding: 70px;
  height: 85vh;
  margin: auto;
  background-color: #fff;
  box-shadow: rgba(149, 157, 165, 0.2) 0px 8px 24px;
  margin-top: 50px;
  margin-bottom: 60px;
  border-radius: 5px;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  flex-wrap: wrap;
  position: relative;
  overflow: hidden;

  img {
    width: 100%;
    height: 96%;
    object-fit: contain;
    position: absolute;
    bottom: 0;
    left: 400px;

    @media screen and (max-width: 768px) {
      left: 90px;
      height: 70%;
    }
  }

  @media screen and (max-width: 768px) {
    width: 100%;
    padding: 20px;
  }
`;
