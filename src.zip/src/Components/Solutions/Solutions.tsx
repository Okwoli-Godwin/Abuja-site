import React, { useState } from "react";
import styled from "styled-components";
import Card from "./Card";
import images from "../Assets/craft.png"
import images2 from "../Assets/craft.png"
import images3 from "../Assets/craft.png"
import images4 from "../Assets/craft.png"
import images5 from "../Assets/craft.png"
import images6 from "../Assets/craft.png"
import images7 from "../Assets/craft.png"
import images8 from "../Assets/craft.png"
import images9 from "../Assets/craft.png"
import images10 from "../Assets/craft.png"
import Pitch from "../Pitch/Pitch";
import Process from "../Process/Process";
import Application from "../Application/Application";

const Solution = () => {
	const [show, setShow] = useState<Boolean>(true);
	const [show2, setShow2] = useState<Boolean>(false);
	const [show3, setShow3] = useState<Boolean>(false);

	const Toogle = () => {
		setShow(true);
		setShow2(false);
		setShow3(false);
	};
	const Toogle2 = () => {
		setShow2(true);
		setShow(false);
		setShow3(false);
	};
	const Toogle3 = () => {
		setShow3(true);
		setShow2(false);
		setShow(false);
	};

	return (
		<Container>

			<ButtonHold>
				<Button bg={show ? "bb" : "" } onClick={Toogle}>
					What is CUR
				</Button>
				<Button bg={show2 ? "bb" : ""} onClick={Toogle2}>
					Grant Process
				</Button>
				<Button bg={show3 ? "bb" : ""} onClick={Toogle3}>
					Application Process
				</Button>
				<Button bg={show3 ? "bb" : ""} onClick={Toogle3}>
					Who can Participate
				</Button>
			</ButtonHold>

			{show ?<Pitch /> : null}

			{show2 ? <Process /> : null}

			{show3 ? <Application /> : null}
		</Container>
	);
};

export default Solution;

const View = styled.div`
	width: 100%;
    height: 100vh;
    display: flex;
    justify-content: center;
    margin-top: 70px;
`;
const View1 = styled.div`
	width: 100%;
    height: 100vh;
    background-color: yellow;
    display: flex;
    justify-content: center;
    margin-top: 70px;
	align-items: center;
`;
const View2 = styled.div``;

const ButtonHold = styled.div`
	margin-top: 10px;
`;
const Button = styled.button<{ bg: string }>`
	height: 75px;
	width: 240px;
	border-radius: 50px;
	position: relative;
	border: 0;
	background-color: ${({ bg }) => (bg ? "#deebff" : "#0052cc")};
	color: ${({ bg }) => (bg ? "#0052cc" : "#deebff")};
	font-size: 20px;
	font-weight: bold;
	cursor: pointer;
	transition: all 350ms;
	margin-right: 10px;
	margin-left: 10px;
	/* :hover {
		transform: scale(0.99);
		background-color: #0052cc;
		color: white;
	} */
`;

const Container = styled.div`
	display: flex;
	justify-content: center;
	align-items: center;
	margin-top: 50px;
	flex-direction: column;
	padding-bottom: 50px;
`;