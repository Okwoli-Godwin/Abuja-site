import React from "react";
import styled from "styled-components";


const Values = () => {
  return (
    <div>
      <Container>
        <TextHolder>
          <Desc>
            <p>OUR VALUES</p>
          </Desc>
          <Title>
            We value measurable impact that directly affects our customers for
            good
          </Title>
        </TextHolder>
        <CardHolder>
          <Card>
            
            <h2>Vision</h2>
            <p>Be Africa’s leading digital insurance company.</p>
          </Card>
          <Card>
            
            <h2>Mission</h2>
            <p>
              Harness the power of technology and strategic partnerships to
              create and effectively distribute impactful insurance products to
              those most in need of it.
            </p>
          </Card>
          <Card>
            
            <h2>Values</h2>
            <p>Focus, Impact, Quality, Efficiency, Ease</p>
          </Card>
        </CardHolder>
      </Container>
    </div>
  );
};

export default Values;

const TextHolder = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;

  @media screen and (max-width: 500px) {
    align-items: flex-start;
  }
`;

const CardHolder = styled.div`
  display: flex;
  flex-wrap: wrap;
  width: 85%;
  margin: auto;

  @media screen and (max-width: 500px) {
    width: 100%;
    margin-top: 10px;
  }
`;

const Card = styled.div`
  padding: 20px;

  img {
    height: 60px;
  }

  h2 {
    font-weight: 500;
  }
  p {
    max-width: 450px;
    font-size: 14px;
    font-family: "Trebuchet MS", "Lucida Sans Unicode", "Lucida Grande",
      "Lucida Sans", Arial, sans-serif;
    line-height: 1.2rem;
    letter-spacing: 0.3px;
    color: #000000dd;
  }
  @media screen and (max-width: 500px) {
    padding: 0;
  }
`;

const Title = styled.h2`
  margin: 0;
  font-size: 2rem;
  font-weight: 500;
  color: #000000db;
  margin-bottom: 20px;
  max-width: 700px;
  text-align: center;

  @media screen and (max-width: 500px) {
    font-size: 1.8rem;
    line-height: 2.3rem;
    max-width: 90%;
    /* text-align: right; */
  }

  @media screen and (max-width: 500px) {
    text-align: left;
  }
`;

const Desc = styled.div`
  text-align: center;
  color: #3e4095;

  p {
    margin: 0;
    margin-bottom: 20px;
  }
`;

const Container = styled.div`
  display: flex;
  flex-direction: column;
  flex-wrap: wrap;

  @media screen and (max-width: 500px) {
    align-items: flex-start;
    padding: 20px;
  }
`;
