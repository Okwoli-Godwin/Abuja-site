import React from "react";
import styled from "styled-components";

const MeetPadies = () => {
  return (
    <div>
      <Container>
        <Top>
          <p>Find out more about us</p>
          <h1>Meet your paddies</h1>
          <h4>
            Paddy is a slang for friend in Nigeria, and as your friend we’ve got
            your back. We work endlessly to give you the best product.
          </h4>
        </Top>
      </Container>
    </div>
  );
};

export default MeetPadies;

// const Top = styled.div``;
// const Top = styled.div``;
// const Top = styled.div``;
// const Top = styled.div``;
// const Top = styled.div``;
const Top = styled.div`
  width: 100%;
  padding: 35px 0px;
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
  flex-wrap: wrap;

  p {
    margin: 0;
    font-size: 14px;
    color: #00000054;
    margin-bottom: 5px;
    font-weight: 500;
  }
  h1 {
    margin: 0;
    font-size: 3.7rem;
    font-weight: 500;
    color: #3e4095;

    @media screen and (max-width: 500px) {
      font-size: 2.3rem;
    }
  }
  h4 {
    margin: 0;
    /* margin-top: 10px; */
    font-weight: 400;
    color: #000000de;
    font-size: 14.3px;
    padding: 12px;
    text-align: center;
    /* width: 350px; */
  }
`;

const Container = styled.div`
  /* width: 100%; */
`;
