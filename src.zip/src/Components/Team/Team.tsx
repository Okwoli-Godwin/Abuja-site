import React from "react";
import styled from "styled-components";
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import SlideProp from "../SlideProp/SlideProp";

const Team = () => {
  const settings = {
    infinite: true,
    speed: 500,
    slidesToShow: 4.2,
    slidesToScroll: 2,
    // initialSlide: 0,
    autoplay: true,
    responsive: [
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 3,
          slidesToScroll: 2,
          infinite: true,
        },
      },
      {
        breakpoint: 600,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 2,
          initialSlide: 2,
        },
      },
      {
        breakpoint: 480,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
        },
      },
    ],
  };

  return (
    <div>
      <Container>
        <TextHolder>
          <Desc>
            <p>MEET THE TEAM</p>
          </Desc>
          <Title>Meet the people who make the magic possible.</Title>
          <p>We work hard and smart together to give you the best product</p>
        </TextHolder>
        <CardHolder>
          <Slider {...settings}>
            <SlideProp name="Okwoli Godwin" role="CEO & Co-Founder" />
            <SlideProp name="Isaac Etor" role="CEO & Co-Founder" />
            <SlideProp name="Okwoli Godwin" role="CEO & Co-Founder" />
            <SlideProp name="Okwoli Godwin" role="CEO & Co-Founder" />
            <SlideProp name="Okwoli Godwin" role="CEO & Co-Founder" />
            <SlideProp name="Okwoli Godwin" role="CEO & Co-Founder" />
          </Slider>
        </CardHolder>
      </Container>
    </div>
  );
};

export default Team;

const TextHolder = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
  margin-bottom: 30px;

  @media screen and (max-width: 500px) {
    align-items: flex-start;
  }

  p {
    margin: 0;
    max-width: 450px;
    font-size: 14px;
    font-family: "Trebuchet MS", "Lucida Sans Unicode", "Lucida Grande",
      "Lucida Sans", Arial, sans-serif;
    line-height: 1.2rem;
    letter-spacing: 0.3px;
    color: #000000dd;
  }
  @media screen and (max-width: 500px) {
    padding: 0;
  }
`;

const CardHolder = styled.div`
  width: 85%;
  margin: auto;
  /* overflow: hidden; */
  margin-top: 20px;
  margin-bottom: 20px;
  /* display: flex; */

  /* @media screen and (max-width: 500px) {
    width: 100%;
    margin-top: 10px;
  } */
`;

const Card = styled.div`
  padding: 20px;

  img {
    height: 60px;
  }

  h2 {
    font-weight: 500;
  }
  p {
    max-width: 450px;
    font-size: 14px;
    font-family: "Trebuchet MS", "Lucida Sans Unicode", "Lucida Grande",
      "Lucida Sans", Arial, sans-serif;
    line-height: 1.2rem;
    letter-spacing: 0.3px;
    color: #000000dd;
  }
  @media screen and (max-width: 500px) {
    padding: 0;
  }
`;

const Title = styled.h2`
  margin: 0;
  font-size: 2rem;
  font-weight: 500;
  color: #000000db;
  margin-bottom: 20px;
  max-width: 600px;
  text-align: center;

  @media screen and (max-width: 500px) {
    font-size: 1.8rem;
    line-height: 2.3rem;
    max-width: 90%;
    /* text-align: right; */
  }

  @media screen and (max-width: 500px) {
    text-align: left;
  }
`;

const Desc = styled.div`
  text-align: center;
  color: #3e4095;

  p {
    margin: 0;
    margin-bottom: 20px;
    color: #3e4095;
  }
`;

const Container = styled.div`
  margin-top: 30px;
  display: flex;
  flex-direction: column;
  flex-wrap: wrap;
  overflow: hidden;

  @media screen and (max-width: 500px) {
    align-items: flex-start;
    padding: 20px;
  }
`;
