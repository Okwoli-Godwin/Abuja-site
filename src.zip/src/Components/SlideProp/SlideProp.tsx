import React from "react";
import styled from "styled-components";
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import img from "../Assets/mat1.jpg"

interface userData {
  name: string;
  role: string;
}

const SlideProp: React.FC<userData> = ({ name, role }) => {
  return (
    <Container>
        <Img src={img} />
    </Container>
    // <div>
    //   <Container>
    //     <CardHolder>
    //       <Top></Top>
    //       <Bottom>
    //         <h2>{name}</h2>
    //         <p>{role}</p>
    //       </Bottom>
    //     </CardHolder>
    //   </Container>
    // </div>
  );
};

export default SlideProp;
const Img = styled.img`
    width: 100%;
    height: 100%;
    object-fit: fill;
`
const Container = styled.div`
    width: 100%;
    /* height: 600px; */
    background-color: green;
    height: 400px;
`

// const CardHolder = styled.div`
//   border-radius: 5px;
//   box-shadow: rgba(17, 17, 26, 0.1) 0px 0px 16px;
//   overflow: hidden;
//   width: 100%;
//   height: 100%;
// `;

// const Bottom = styled.div`
//   width: 250px;
//   padding: 10px;
//   background-color: #fff;
//   color: #3e4095;
//   h2 {
//     margin: 0;
//     max-width: 80%;
//     font-weight: 500;
//   }
//   p {
//     margin: 0;
//     padding-top: 10px;
//   }
// `;

// const Top = styled.div`
//   width: 270px;
//   height: 820px;
//   background-color: #dd168d;
// `;
// const Container = styled.div`
//   display: flex;
//   justify-content: center;
//   align-items: center;
//   width: 50%;
//   height: 400px;
//   background-color: green;
// `;
