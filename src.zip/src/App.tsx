import React from 'react'
import Allroutes from './Components/Allroutes'
import Footer from './Components/Footer/Footer'
import Header from './Components/Header/Header'

const App = () => {
  return (
    <div>
      <Header />
      <Allroutes />
      {/* <Footer /> */}
    </div>
  )
}

export default App